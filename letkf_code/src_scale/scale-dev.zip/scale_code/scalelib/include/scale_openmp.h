#define OMP_SCHEDULE_ schedule(static)
